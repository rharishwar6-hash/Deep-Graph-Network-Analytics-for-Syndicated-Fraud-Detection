# Project 3 — Deep Graph Network Analytics for Syndicated Fraud Detection

## Dataset type
Fully synthetic, generated for academic/project practice. No real customer, bank, device, or IP data is included.

## Files
- users.csv — user/entity metadata and planted ring membership label
- devices.csv — device metadata
- bank_accounts.csv — bank/wallet account metadata
- user_accounts.csv — user-to-account ownership edges
- user_device.csv — user-to-device relationships; planted rings share devices
- user_ip.csv — user-to-IP relationships; planted rings share IP identifiers
- transactions.csv — directed account/user transfers with timestamps, amounts and ground-truth suspicious labels
- fraud_rings_ground_truth.csv — planted fraud-ring membership and pattern description for evaluation only

## Approximate size
1,000 users; 850 devices; 1,100 accounts; 1,000 user-device links; 1,000 user-IP links; 5,660 transactions; 8 planted fraud rings.

## Suggested graph model
Nodes: User, Device, IPAddress, Account
Edges: OWNS, USES_DEVICE, CONNECTED_FROM, TRANSFERRED_TO
Use transaction_id, amount, currency, transaction_timestamp and channel as relationship properties.

## Suggested workflow
1. Load the CSVs into Neo4j or NetworkX.
2. Calculate degree, betweenness centrality and shortest paths.
3. Run Louvain/Leiden community detection.
4. Generate Node2Vec/GraphSAGE embeddings.
5. Use PageRank variants and cycle detection to identify suspicious structures.
6. Train an XGBoost model using graph-derived features.

## Important
Use `is_suspicious_ground_truth`, `is_fraud_ring_member` and `fraud_ring_id` only as evaluation labels / ground truth. Exclude them from unsupervised graph discovery and from model input features to avoid target leakage.
